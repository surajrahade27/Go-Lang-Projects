###### ServerProject in Golang
you can just run .exe file or do
$ go run main.go