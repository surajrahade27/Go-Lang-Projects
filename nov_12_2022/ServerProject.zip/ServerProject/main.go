package main

import (
	"fmt"
	"log"
	"net/http"
)

var myArray []string

// myArray[0] = "India"  // Assign a value to the first element
// myArray[1] = "Canada" // Assign a value to the second element
// myArray[2] = "Japan"  // Assign a value to the third element
func formHandler(w http.ResponseWriter, r *http.Request) {
	if err := r.ParseForm(); err != nil {
		fmt.Fprintf(w, "ParseForm() Error err: %v", err)
	}
	fmt.Fprintf(w, "POST Request SuccessFull.\n")
	name := r.FormValue("name")
	address := r.FormValue("address")

	fmt.Fprintf(w, "Name = %s\n", name)
	fmt.Fprintf(w, "Add = %s\n", address)

}
func helloHandler(w http.ResponseWriter, r *http.Request) {

	if r.URL.Path != "/hello" {
		http.Error(w, "404 Not Found", http.StatusNotFound)
		return
	}
	if r.Method != "GET" {
		http.Error(w, "Method is not supported", http.StatusNotFound)
	}
	fmt.Fprintf(w, "HELLOWWW folks!")
} //end
func pushHandler(w http.ResponseWriter, r *http.Request) {
	fmt.Println("PUSH started")
	if err := r.ParseForm(); err != nil {
		fmt.Fprintf(w, "ParseForm() Error err: %v", err)
	}
	fmt.Fprintf(w, "PUSH Request SuccessFull.\n\n\n\n")
	data := r.FormValue("data")
	fmt.Fprintf(w, "Before myArray:= %s  \n\n\n", myArray)
	fmt.Fprintf(w, "Incoming Data = %s\n\n\n", data)
	// arrLen := size(myArray) + 1
	myArray = append(myArray, data)
	fmt.Fprintf(w, "After myArray:= %s  \n\n\n", myArray)
	fmt.Println("PUSH ended")
} //end
func popHandler(w http.ResponseWriter, r *http.Request) {
	fmt.Println("Pop started")
	if err := r.ParseForm(); err != nil {
		fmt.Fprintf(w, "ParseForm() Error err: %v", err)
	}
	fmt.Fprintf(w, "POP Request SuccessFull.\n\n\n\n")
	fmt.Fprintf(w, "Before Pop,\n myArray:= %s  \n\n\n", myArray)
	// arrLen := size(myArray) + 1
	// myArray = append(myArray, data)
	myArray = myArray[:len(myArray)-1]
	fmt.Fprintf(w, "After POP, \n myArray:= %s  \n\n\n", myArray)
	fmt.Println("Pop- ended")
} //end
func main() {
	fmt.Println("Execution Started : ")

	fileserver := http.FileServer(http.Dir("./static"))
	http.Handle("/", fileserver)
	http.HandleFunc("/form", formHandler)
	http.HandleFunc("/push", pushHandler)
	http.HandleFunc("/pop", popHandler)
	http.HandleFunc("/hello", helloHandler)

	fmt.Printf("Starting Server @ port 8080 \n")

	if err := http.ListenAndServe(":8080", nil); err != nil {
		log.Fatal(err)
	}

}
