// package main

// import (
// 	"encoding/json"
// 	"fmt"
// 	"io"
// 	"os"
// )

// type Sensor struct {
// 	id       uint   `json:"id" gorm:"primary_key"`
// 	UnixTime string `json:"unixTime"`
// 	Temp     int    `json:"temp"`
// 	Co       int    `json:"co"`
// 	Co2      int    `json:"co2"`
// }

// func main() {

// 	// Open our jsonFile
// 	var sensor []Sensor

// 	jsonFile, err := os.Open("./MOCK_DATA.json")
// 	if err != nil {
// 		fmt.Println(err)
// 	}
// 	fmt.Println("Successfully Opened sensors.json")
// 	defer jsonFile.Close()
// 	byteValue, _ := io.ReadAll(jsonFile)

// 	json.Unmarshal(byteValue, &sensor)
// 	fmt.Println(sensor)
// }
